import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-press-popover',
  templateUrl: './press-popover.component.html',
  styleUrls: ['./press-popover.component.scss'],
})
export class PressPopoverComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
