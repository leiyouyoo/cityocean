import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sailing-detail',
  templateUrl: './sailing-detail.page.html',
  styleUrls: ['./sailing-detail.page.scss'],
})
export class SailingDetailPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
