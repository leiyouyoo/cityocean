export enum TransportationMode {
  ocean = 0,
  air = 1
}

