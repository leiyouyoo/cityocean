export enum bookingStatus{
    Draft=0,
    Cancelled=1,
    Submitted=2,
    Booked=3,
    WaitingForPricing=4,
    WaitingForBuyer=5,
    WaitingForSellerr=6,
    ConfirmCancelled=7
}