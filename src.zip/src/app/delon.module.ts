/**
 * 进一步对基础模块的导入提炼
 * 有关模块注册指导原则请参考：https://github.com/ng-alain/ng-alain/issues/180
 */
import { NgModule, Optional, SkipSelf, ModuleWithProviders } from '@angular/core';
import { throwIfAlreadyLoaded } from '@core';

import { AlainThemeModule } from '@delon/theme';
import { DelonACLModule } from '@delon/acl';

// #region mock
import { DelonMockModule } from '@delon/mock';
// import * as MOCKDATA from '../../_mock';
import { environment } from '@env/environment';

function mockDataFactory() {
  const reg = /CoMock\//;
  const data = {};
  // tslint:disable-next-line:forin
  for (const mockdataKey in data) {
    // tslint:disable-next-line:forin
    for (const mockdataKeyKey in data[mockdataKey]) {
      data[mockdataKey][mockdataKeyKey.replace(reg, '')] = data[mockdataKey][mockdataKeyKey];
    }
  }
  return data;
}

// const MOCK_MODULES = environment.production ? [DelonMockModule.forRoot({ data: MOCKDATA, force: false, executeOtherInterceptors: false })] : [];
// #endregion

// #region reuse-tab
/**
 * 若需要[路由复用](https://ng-alain.com/components/reuse-tab)需要：
 * 1、增加 `REUSETAB_PROVIDES`
 * 2、在 `src/app/layout/default/default.component.html` 修改：
 *  ```html
 *  <section class="alain-default__content">
 *    <reuse-tab></reuse-tab>
 *    <router-outlet></router-outlet>
 *  </section>
 *  ```
 */
import { RouteReuseStrategy } from '@angular/router';
import { ReuseTabService, ReuseTabStrategy, ReuseTabMatchMode } from '@delon/abc/reuse-tab';
const REUSETAB_PROVIDES = [
  {
    provide: RouteReuseStrategy,
    useClass: ReuseTabStrategy,
    deps: [ReuseTabService],
  },
];
// #endregion

// #region global config functions

import { PageHeaderConfig } from '@delon/abc';
export function fnPageHeaderConfig(): PageHeaderConfig {
  return {
    ...new PageHeaderConfig(),
    homeI18n: 'home',
    recursiveBreadcrumb: true,
  };
}

import { DelonAuthConfig } from '@delon/auth';
export function fnDelonAuthConfig(): DelonAuthConfig {
  return {
    ...new DelonAuthConfig(),
    login_url: '/login',
    ignores: [/sso\/connect\/token/, /assets\//, /passport\//, /login\//],
  };
}

// tslint:disable-next-line: no-duplicate-imports
import { STConfig } from '@delon/abc';
export function fnSTConfig(): STConfig {
  return {
    ...new STConfig(),
    modal: { paramsName: 'i', size: 'lg' },
    page: { toTop: true, toTopOffset: 0 },
  };
}

import { DelonFormConfig } from '@delon/form';
export function fnDelonFormConfig(): DelonFormConfig {
  return {
    ...new DelonFormConfig(),
  };
}

const GLOBAL_CONFIG_PROVIDES = [
  // TIPS：@delon/abc 有大量的全局配置信息，例如设置所有 `st` 的页码默认为 `20` 行
  { provide: STConfig, useFactory: fnSTConfig },
  { provide: DelonFormConfig, useFactory: fnDelonFormConfig },
  { provide: PageHeaderConfig, useFactory: fnPageHeaderConfig },
  { provide: DelonAuthConfig, useFactory: fnDelonAuthConfig },
];

// #endregion

@NgModule({
  imports: [
    AlainThemeModule.forRoot(),
    DelonACLModule.forRoot(),
    // mock
    //...MOCK_MODULES,
  ],
})
export class DelonModule {
  constructor(@Optional() @SkipSelf() parentModule: DelonModule, reuseTabSrv: ReuseTabService) {
    throwIfAlreadyLoaded(parentModule, 'DelonModule');
    reuseTabSrv.mode = ReuseTabMatchMode.MenuForce;
  }

  static forRoot(): ModuleWithProviders {
    return {
      ngModule: DelonModule,
      providers: [...REUSETAB_PROVIDES, ...GLOBAL_CONFIG_PROVIDES],
    };
  }
}
